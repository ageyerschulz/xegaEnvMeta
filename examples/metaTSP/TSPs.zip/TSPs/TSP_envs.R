library(TSP)
library(xega)

newTSP<-function(D, Cities=0, Name, Solution=NA, Path=NA)
{
  parm<-function(x){function() {return(x)}}	
  d<-dim(D)
  try (if (!length(d)==2) stop("n times n matrix expected"))
  try (if (!d[1]==d[2]) stop("n times n matrix expected"))
  # constant functions
  self<-list()
  self$name<-parm(Name)
  self$genelength<- parm(d[1])
  self$dist<-parm(D)
  if (identical(Cities,0)) {cit<-1:length(Path)} else {cit<-Cities}
  self$cities<-parm(cit)
  self$path<-parm(Path)
  # f
  self$f<-function(permutation, gene=0, lF=0, tour=TRUE)
  { cost<-0
  l<-length(permutation)-1
  for (i in 1:l)
  { cost<- cost+self$dist()[permutation[i], permutation[i+1]]}
  if (tour==TRUE) {cost<-cost+self$dist()[permutation[l+1], permutation[1]]}
  return(cost)}
  self$max<-function() {return(FALSE)}
  self$globalOptimum<-function() 
  {l<-list();l$param<-rep(NA,d[1]); l$value<-Solution;l$is.minimum<-TRUE;return(l)}
  
  # show. p is a path.
  self$show<-function(p)
  { l<-length(p)-1
  pl<-0
  for (i in 1:l)
  {d<-self$dist()[p[i], p[i+1]]
  pl<-pl+d
  cat(i,"Length:", pl, 
      " from:", self$cities()[p[i]], " to ", self$cities()[p[i+1]],
      " Distance: ", d, "\n")}
  d<-self$dist()[p[l+1], p[1]]
  pl<-pl+d
  cat(i,"Length:", pl, 
      " from:", self$cities()[p[l+1]], " to ", self$cities()[p[1]],
      " Distance: ", d, "\n")}
  a<-force(self$name())
  a<-force(self$genelength())
  a<-force(self$dist())
  a<-force(self$cities())
  a<-force(self$path())
  a<-force(self$max())
  a<-force(self$globalOptimum())
  return(self) }

a<-matrix(0, nrow=15, ncol=15)

a[1,]<- c(0, 29, 82, 46, 68, 52, 72, 42, 51,  55,  29,  74,  23,  72,  46)
a[2,]<- c(29,  0, 55, 46, 42, 43, 43, 23, 23,  31,  41,  51,  11,  52,  21)
a[3,]<- c(82, 55,  0, 68, 46, 55, 23, 43, 41,  29,  79,  21,  64,  31,  51)
a[4,]<-c(46, 46, 68,  0, 82, 15, 72, 31, 62,  42,  21,  51,  51,  43,  64)
a[5,]<-c(68, 42, 46, 82,  0, 74, 23, 52, 21,  46,  82,  58,  46,  65,  23)
a[6,]<-c(52, 43, 55, 15, 74,  0, 61, 23, 55,  31,  33,  37,  51,  29,  59)
a[7,]<-c(72, 43, 23, 72, 23, 61,  0, 42, 23,  31,  77,  37,  51,  46,  33)
a[8,]<-c(42, 23, 43, 31, 52, 23, 42,  0, 33,  15,  37,  33,  33,  31,  37)
a[9,]<-c(51, 23, 41, 62, 21, 55, 23, 33,  0,  29,  62,  46,  29,  51,  11)
a[10,]<-c(55, 31, 29, 42, 46, 31, 31, 15, 29,  0,  51,  21,  41,  23,  37)
a[11,]<-c(29, 41, 79, 21, 82, 33, 77, 37, 62,  51,   0,  65,  42,  59,  61)
a[12,]<-c(74, 51, 21, 51, 58, 37, 37, 33, 46,  21,  65,   0,  61,  11,  55)
a[13,]<-c(23, 11, 64, 51, 46, 51, 51, 33, 29,  41,  42,  61,   0,  62,  23)
a[14,]<-c(72, 52, 31, 43, 65, 29, 46, 31, 51,  23,  59,  11,  62,   0,  59)
a[15,]<-c(46, 21, 51, 64, 23, 59, 33, 37, 11,  37,  61,  55,  23,  59,   0)

path<-c(1, 13, 2, 15, 9, 5, 7, 3, 12, 14, 10, 8, 6, 4, 11)
#lau<-newTSP(a, Name="lau15", Solution= 291, Path=path)


#a<-xegaRun(penv=lau, max=FALSE, algorithm="sgperm", genemap="Identity", generations=1000, popsize=100, verbose=2)

envs <- list()
f <- c("gr17.tsp", "gr48.tsp", "gr120.tsp", "brg180.tsp", "si535.tsp", "si1032.tsp")
names <- c("name", "name")
solutions <- c(2085, 5046, 6942, 1950, 48450, 92650)
for (i in 1:6) {
  data <- as.matrix(read_TSPLIB(f[i]))
  envs[[i]] <- newTSP(data, Name=f[i], Solution=solutions[i])
}

a<-xegaRun(penv=envs[[1]], max=FALSE, algorithm="sgperm", genemap="Identity", generations=100, popsize=100, verbose=2)
  
i = 6
data <- as.matrix(read_TSPLIB(f[i]))
env <- newTSP(data, Name=f[i], Solution=solutions[i])